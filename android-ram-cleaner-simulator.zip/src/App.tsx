import { useState, useEffect, useRef } from "react";
import { 
  Smartphone, 
  RefreshCw, 
  Code, 
  Check, 
  Sparkles, 
  Send, 
  Shield, 
  Play, 
  ArrowRight, 
  BookOpen, 
  Layers, 
  CheckCircle2, 
  Info, 
  Cpu, 
  ChevronRight, 
  RotateCcw,
  ShieldAlert, 
  HelpCircle,
  Copy,
  ExternalLink,
  MessageSquare
} from "lucide-react";
import { generateCodeSnippets } from "./codeGenerator";
import { AndroidVersion, ExperienceLevel, MockApp, CodeSnippet, ChatMessage } from "./types";

const INITIAL_APPS: MockApp[] = [
  { id: "1", name: "Instagram", packageName: "com.instagram.android", ramMb: 142, initialRamMb: 142, isSystem: false, isWhitelisted: false, status: "active", category: "Red Social", iconName: "Instagram" },
  { id: "2", name: "TikTok Lite", packageName: "com.zhiliaoapp.musically.go", ramMb: 350, initialRamMb: 350, isSystem: false, isWhitelisted: false, status: "active", category: "Red Social", iconName: "Video" },
  { id: "3", name: "Chrome Mobile", packageName: "com.android.chrome", ramMb: 215, initialRamMb: 215, isSystem: false, isWhitelisted: false, status: "active", category: "Utilidad", iconName: "Globe" },
  { id: "4", name: "WhatsApp", packageName: "com.whatsapp", ramMb: 95, initialRamMb: 95, isSystem: false, isWhitelisted: true, status: "active", category: "Red Social", iconName: "MessageSquare" },
  { id: "5", name: "Spotify Lite", packageName: "com.spotify.lite", ramMb: 110, initialRamMb: 110, isSystem: false, isWhitelisted: false, status: "active", category: "Utilidad", iconName: "Music" },
  { id: "6", name: "Free Fire (Juego)", packageName: "com.dts.freefireth", ramMb: 430, initialRamMb: 430, isSystem: false, isWhitelisted: false, status: "active", category: "Juego", iconName: "Gamepad" },
  { id: "7", name: "Android Core OS", packageName: "com.android.system", ramMb: 310, initialRamMb: 310, isSystem: true, isWhitelisted: true, status: "active", category: "Sistema", iconName: "Cpu" },
  { id: "8", name: "System UI", packageName: "com.android.systemui", ramMb: 180, initialRamMb: 180, isSystem: true, isWhitelisted: true, status: "active", category: "Sistema", iconName: "Layers" }
];

const PRE_SUGGESTED_PROMPTS = [
  {
    label: "¿Qué es el LMK?",
    prompt: "Explícame qué es el LMK (Low Memory Killer) de Android y por qué entra en conflicto con las apps de limpieza comunes."
  },
  {
    label: "¿Por qué falla killBackgroundProcesses()?",
    prompt: "Explícame con total honestidad por qué las llamadas a ActivityManager.killBackgroundProcesses() ya no liberan memoria de verdad en Android modernos."
  },
  {
    label: "Permiso de Accesibilidad",
    prompt: "¿Cómo se activa programáticamente o se solicita el permiso de Accesibilidad al usuario desde una app real en Kotlin?"
  },
  {
    label: "Evitar Ban de Google Play",
    prompt: "¿Cuáles son las políticas de Google Play sobre el uso de AccessibilityService para forzar detenciones en apps de limpieza? ¿Cómo evitar que rechacen mi app?"
  }
];

export default function App() {
  // Simulator states
  const [apps, setApps] = useState<MockApp[]>(INITIAL_APPS);
  const [androidVersion, setAndroidVersion] = useState<AndroidVersion>("Android 11_13");
  const [experienceLevel, setExperienceLevel] = useState<ExperienceLevel>("Principiante");
  const [copiedSnippetIdx, setCopiedSnippetIdx] = useState<number | null>(null);
  
  // Simulation control
  const [isSimulating, setIsSimulating] = useState(false);
  const [currentSimAppIndex, setCurrentSimAppIndex] = useState<number | null>(null);
  const [simStep, setSimStep] = useState<"not_started" | "opening_settings" | "clicking_stop" | "confirming_modal" | "closing">("not_started");
  const [simulationSpeed, setSimulationSpeed] = useState<"normal" | "slow" | "fast">("normal");
  const [ramFreedSum, setRamFreedSum] = useState(0);

  // Active Code Snippet tab
  const [activeSnippetTab, setActiveSnippetTab] = useState(2); // default to MainActivity.kt (index 2)

  // Chat states
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: "init-1",
      role: "assistant",
      content: "¡Hola! Soy tu Consultor Experto en Sistemas Android. Estoy listo para ayudarte a entender los entresijos de la administración de memoria en teléfonos con recursos de 2GB de RAM.\n\nPuedo explicarte cómo funciona el planificador, las limitaciones técnicas que impone Google hoy en día, o guiarte línea por línea en el código de accesibilidad en Kotlin. ¿Qué te gustaría consultar hoy?",
      timestamp: new Date()
    }
  ]);
  const [chatInput, setChatInput] = useState("");
  const [isSendingChat, setIsSendingChat] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Generate Snippets on settings change
  const snippets = generateCodeSnippets(androidVersion, experienceLevel);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages]);

  // Compute stats
  const usedRamMb = apps.reduce((acc, app) => acc + (app.status === "killed" ? 0 : app.ramMb), 0);
  const totalRamAvailable = 2048; // 2GB
  const minRequiredRam = 612; // System OS always needed
  const ramPercentage = Math.round((usedRamMb / totalRamAvailable) * 100);

  // Toggle whitelist switch
  const handleToggleWhitelist = (id: string) => {
    if (isSimulating) return;
    setApps(prev => prev.map(app => {
      if (app.id === id) {
        // System apps should always stay whitelisted
        if (app.isSystem) return app;
        return { ...app, isWhitelisted: !app.isWhitelisted };
      }
      return app;
    }));
  };

  // Reset simulator
  const handleResetSimulator = () => {
    setIsSimulating(false);
    setCurrentSimAppIndex(null);
    setSimStep("not_started");
    setApps(INITIAL_APPS);
    setRamFreedSum(0);
  };

  // Run automatic force stop sequence
  const startForceStopSequence = () => {
    if (isSimulating) return;
    
    // Find non-whitelisted apps that are active
    const targets = apps.filter(app => !app.isWhitelisted && app.status === "active");
    if (targets.length === 0) {
      alert("No hay aplicaciones seleccionadas para cerrar que no estén en la lista de ignorados (Whitelist) o que ya estén detenidas.");
      return;
    }

    setIsSimulating(true);
    runNextSequenceItem(0);
  };

  // Recursive sequence runner mimicking Greenify automation
  const runNextSequenceItem = (targetIdxInFiltered: number) => {
    const targets = apps.filter(app => !app.isWhitelisted && app.status === "active");
    
    if (targetIdxInFiltered >= targets.length) {
      // Completed!
      setTimeout(() => {
        setIsSimulating(false);
        setCurrentSimAppIndex(null);
        setSimStep("not_started");
      }, 1000);
      return;
    }

    const currentTarget = targets[targetIdxInFiltered];
    const originalAppIdx = apps.findIndex(a => a.id === currentTarget.id);
    
    setCurrentSimAppIndex(originalAppIdx);
    
    const delays = {
      opening_settings: simulationSpeed === "slow" ? 2200 : simulationSpeed === "fast" ? 800 : 1400,
      clicking_stop: simulationSpeed === "slow" ? 1800 : simulationSpeed === "fast" ? 600 : 1100,
      confirming_modal: simulationSpeed === "slow" ? 1800 : simulationSpeed === "fast" ? 600 : 1100,
      closing: simulationSpeed === "slow" ? 1200 : simulationSpeed === "fast" ? 400 : 800,
    };

    // Step 1: Open settings page
    setSimStep("opening_settings");

    setTimeout(() => {
      // Step 2: Highlighting button & clicking
      setSimStep("clicking_stop");

      setTimeout(() => {
        // Step 3: Dialog pops up
        setSimStep("confirming_modal");

        setTimeout(() => {
          // Step 4: Kill application actually, free RAM, then repeat
          setApps(prev => prev.map(app => {
            if (app.id === currentTarget.id) {
              return { ...app, status: "killed", ramMb: 0 };
            }
            return app;
          }));
          setRamFreedSum(prev => prev + currentTarget.ramMb);
          setSimStep("closing");

          setTimeout(() => {
            // Keep going with next app
            runNextSequenceItem(targetIdxInFiltered + 1);
          }, delays.closing);

        }, delays.confirming_modal);

      }, delays.clicking_stop);

    }, delays.opening_settings);
  };

  // Copy code utility
  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedSnippetIdx(index);
    setTimeout(() => {
      setCopiedSnippetIdx(null);
    }, 2000);
  };

  // Chat request flow to server with Gemini
  const handleSendChat = async (textToSend?: string) => {
    const rawMsg = textToSend || chatInput;
    if (!rawMsg.trim()) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      content: rawMsg,
      timestamp: new Date()
    };

    setChatMessages(prev => [...prev, userMsg]);
    if (!textToSend) setChatInput("");
    setIsSendingChat(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: rawMsg,
          history: chatMessages.map(m => ({ role: m.role, content: m.content })),
          deviceConfig: {
            androidVersion,
            experienceLevel
          }
        })
      });

      const data = await response.json();
      
      let assistantResponseText = "Disculpa, no logré obtener una respuesta del servidor.";
      if (data && data.response) {
        assistantResponseText = data.response;
      } else if (data && data.error) {
        assistantResponseText = `Error desde la API de Gemini: ${data.details || data.error}`;
      }

      setChatMessages(prev => [...prev, {
        id: `assist-${Date.now()}`,
        role: "assistant",
        content: assistantResponseText,
        timestamp: new Date()
      }]);
    } catch (e: any) {
      console.error(e);
      setChatMessages(prev => [...prev, {
        id: `assist-${Date.now()}`,
        role: "assistant",
        content: "Error de red: No se pudo conectar con el servidor backend. Por favor verifica los Logs del Applet o vuelve a intentarlo.",
        timestamp: new Date()
      }]);
    } finally {
      setIsSendingChat(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 font-sans antialiased selection:bg-blue-100 selection:text-blue-900">
      
      {/* Header Bar */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50 px-6 py-4 shadow-xs">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="bg-slate-900 text-white p-2.5 rounded-xl flex items-center justify-center shadow-xs">
              <Cpu className="w-6 h-6 text-green-400" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-xl font-bold tracking-tight text-slate-900">Revive RAM</h1>
                <span className="bg-blue-50 text-blue-700 text-[11px] font-semibold tracking-wider px-2 py-0.5 rounded-md border border-blue-100 uppercase">
                  Project Alpha
                </span>
              </div>
              <p className="text-xs text-slate-500">Android 2GB RAM Optimizer Code Lab & Interactive Simulator</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center space-x-2 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg">
              <span className="w-2.5 h-2.5 rounded-full bg-green-500 animate-pulse"></span>
              <span className="text-xs font-semibold text-slate-700 uppercase tracking-wider">Servicio de Accesibilidad Listo</span>
            </div>
            <a 
              href="#codelab" 
              className="text-xs font-semibold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 px-3 py-1.5 rounded-lg shadow-2xs hover:shadow-xs transition duration-150"
            >
              Ir al Código Kotlin
            </a>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 md:px-6 py-8">
        
        {/* Intro Alert: Explaining Android memory honestly */}
        <section className="bg-white border-l-4 border-amber-500 p-5 rounded-r-2xl shadow-xs mb-8">
          <div className="flex items-start space-x-3">
            <div className="text-amber-500 mt-0.5 flex-shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-950 uppercase tracking-wide">La verdad sobre los optimizadores de RAM modernos</h2>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                La mayoría de limpiadores en tiendas simulan borrar procesos llamando a <code className="bg-slate-100 text-pink-600 px-1 py-0.5 rounded font-mono text-[11px]">killBackgroundProcesses()</code> sin Root. Pero en versiones de Android modernas, el sistema operativo<strong> los recarga de inmediato</strong> para mantener la caché del sistema activa, consumiendo el doble de batería.
              </p>
              <div className="mt-3 flex items-center space-x-2 text-[11px] font-semibold text-slate-800">
                <span>¿La única forma real no-root?</span>
                <span className="bg-amber-100 text-amber-800 px-2 py-0.5 rounded-md">Automating Settings &gt; Force Stop</span>
                <span>mediante un <strong className="text-amber-950 font-bold">AccessibilityService</strong> en Kotlin.</span>
              </div>
            </div>
          </div>
        </section>

        {/* Dynamic Layout according to Clean Minimalism Guidelines */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* COLUMN 1: LEFT CONFIGURATION PANEL (lg:col-span-3) */}
          <section className="lg:col-span-3 space-y-6">
            
            {/* Live Configuration Card */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Ajustes del Compilador</h3>
              
              {/* Android Version Selector */}
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">Versión de Target Android:</label>
                  <div className="grid grid-cols-1 gap-2">
                    <button 
                      onClick={() => setAndroidVersion("Android 9")}
                      className={`w-full py-2 px-3 text-left rounded-xl border text-xs font-medium transition ${
                        androidVersion === "Android 9" 
                          ? "bg-slate-900 border-slate-900 text-white" 
                          : "bg-white hover:bg-slate-50 border-slate-200 text-slate-700"
                      }`}
                    >
                      <div className="font-semibold">Android 9 (Pie)</div>
                      <div className="text-[10px] opacity-70">API 28 • Sin restricciones rígidas</div>
                    </button>

                    <button 
                      onClick={() => setAndroidVersion("Android 10")}
                      className={`w-full py-2 px-3 text-left rounded-xl border text-xs font-medium transition ${
                        androidVersion === "Android 10" 
                          ? "bg-slate-900 border-slate-900 text-white" 
                          : "bg-white hover:bg-slate-50 border-slate-200 text-slate-700"
                      }`}
                    >
                      <div className="font-semibold">Android 10 (Q)</div>
                      <div className="text-[10px] opacity-70">API 29 • Privacidad reforzada</div>
                    </button>

                    <button 
                      onClick={() => setAndroidVersion("Android 11_13")}
                      className={`w-full py-2 px-3 text-left rounded-xl border text-xs font-medium transition ${
                        androidVersion === "Android 11_13" 
                          ? "bg-slate-900 border-slate-900 text-white" 
                          : "bg-white hover:bg-slate-50 border-slate-200 text-slate-700"
                      }`}
                    >
                      <div className="font-semibold">Android 11-13 (R/T)</div>
                      <div className="text-[10px] opacity-70">Requiere QUERY_ALL_PACKAGES</div>
                    </button>

                    <button 
                      onClick={() => setAndroidVersion("Android 14")}
                      className={`w-full py-2 px-3 text-left rounded-xl border text-xs font-medium transition ${
                        androidVersion === "Android 14" 
                          ? "bg-slate-900 border-slate-900 text-white" 
                          : "bg-white hover:bg-slate-50 border-slate-200 text-slate-700"
                      }`}
                    >
                      <div className="font-semibold">Android 14 (U)</div>
                      <div className="text-[10px] opacity-70">Filtro estricto de hilos de background</div>
                    </button>
                  </div>
                </div>

                {/* Experience Level */}
                <div className="pt-2 border-t border-slate-100">
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">Complejidad del Código:</label>
                  <div className="flex rounded-lg bg-slate-100 p-1">
                    <button 
                      onClick={() => setExperienceLevel("Principiante")}
                      className={`flex-1 py-1.5 text-[11px] font-bold rounded-md transition ${experienceLevel === "Principiante" ? "bg-white text-slate-900 shadow-2xs" : "text-slate-500 hover:text-slate-800"}`}
                    >
                      Principiante
                    </button>
                    <button 
                      onClick={() => setExperienceLevel("Avanzado")}
                      className={`flex-1 py-1.5 text-[11px] font-bold rounded-md transition ${experienceLevel === "Avanzado" ? "bg-white text-slate-900 shadow-2xs" : "text-slate-500 hover:text-slate-800"}`}
                    >
                      Avanzado C++ / Threading
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* RAM 2GB Device constraints info */}
            <div className="bg-amber-50 rounded-2xl p-5 border border-amber-100 text-slate-800 text-xs space-y-3">
              <div className="flex items-center space-x-2 text-slate-900 font-bold uppercase tracking-wider text-[11px]">
                <Smartphone className="w-4 h-4 text-amber-600" />
                <span>¿Por qué 2GB es crítico?</span>
              </div>
              <p className="leading-relaxed">
                Los smartphones Android de 2GB de RAM tienen asignaciones estrictas. La huella base del Sistema Operativo ocupa de media <strong>1.1 GB a 1.3 GB</strong>. 
              </p>
              <p className="leading-relaxed">
                Cualquier app redundante en segundo plano de más de 120MB (como Instagram o TikTok) iniciará el <strong>LMK (Low Memory Killer)</strong>, ralentizando y cerrando tus apps de mensajería (como WhatsApp) a la mitad de su ejecución.
              </p>
            </div>

            {/* Why this works - Honest logic */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide mb-2 flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-green-500" />
                <span>¿Por qué es Real?</span>
              </h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Bajo la bandera de la accesibilidad, simulamos la ruta nativa que un desarrollador haría a mano. El sistema no puede ignorar el Force Stop porque es una directiva del propio gestor de paquetes de bajo nivel (PackageManager).
              </p>
            </div>

          </section>

          {/* COLUMN 2: CENTER DEVICE SIMULATOR (lg:col-span-5) */}
          <section className="lg:col-span-5 flex flex-col items-center">
            
            {/* Visual Phone Model */}
            <div className="w-full max-w-[380px] bg-slate-950 rounded-[3.25rem] border-[12px] border-slate-900 shadow-2xl relative flex flex-col overflow-hidden mb-6">
              
              {/* Phone Camera Notch */}
              <div className="h-6 w-1/3 bg-slate-900 absolute top-0 left-1/2 -translate-x-1/2 rounded-b-2xl z-20 flex items-center justify-center">
                <div className="w-3.5 h-3.5 bg-slate-950 rounded-full border border-slate-800"></div>
              </div>

              {/* Status bar inside phone screen */}
              <div className="bg-slate-900 px-6 pt-7 pb-2 text-[10px] text-slate-400 flex justify-between items-center font-mono border-b border-slate-800">
                <span>02:37 AM</span>
                <div className="flex items-center space-x-1.5">
                  <span className="text-xs">🔋 84%</span>
                  <span className="bg-green-500 text-white text-[9px] px-1 rounded-sm uppercase tracking-tighter">2GB Limit</span>
                </div>
              </div>

              {/* Clean Minimalist UI - Internal Header */}
              <div className="bg-white px-5 py-4 border-b border-slate-100">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Panel del Dispositivo</span>
                  <span className="text-[10px] font-bold text-green-600 px-2 py-0.5 bg-green-50 rounded-md border border-green-100 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
                    Servicio Activo
                  </span>
                </div>

                {/* Circular RAM Gauge */}
                <div className="flex flex-col items-center py-2">
                  <div className="relative w-32 h-32 flex items-center justify-center">
                    <svg className="absolute w-full h-full transform -rotate-90">
                      {/* Grey background circle */}
                      <circle 
                        cx="64" 
                        cy="64" 
                        r="52" 
                        stroke="#F1F5F9" 
                        strokeWidth="8" 
                        fill="transparent" 
                      />
                      {/* Active RAM stroke circle */}
                      <circle 
                        cx="64" 
                        cy="64" 
                        r="52" 
                        stroke="#2563EB" 
                        strokeWidth="8" 
                        fill="transparent" 
                        strokeDasharray="326.7" 
                        strokeDashoffset={326.7 - (326.7 * ramPercentage) / 100}
                        className="transition-all duration-700 ease-out text-blue-600"
                      />
                    </svg>
                    
                    <div className="flex flex-col items-center z-10">
                      <span className="text-3xl font-extrabold text-slate-800 tracking-tight">{ramPercentage}%</span>
                      <span className="text-[9px] uppercase text-slate-400 font-bold tracking-wider">RAM Usada</span>
                    </div>
                  </div>
                  
                  <p className="mt-3 text-xs text-slate-500 font-medium text-center">
                    {usedRamMb} MB / {totalRamAvailable} MB Consumidos
                  </p>
                </div>
              </div>

              {/* LIST OF APPLICATIONS (OR ACTIVE WORKSPACE LAYOUT) */}
              <div className="flex-1 bg-white px-4 py-3 overflow-y-auto max-h-[310px] relative">
                
                {/* Simulated Settings / Accessibility Screen overlay when executing sequence */}
                {isSimulating && currentSimAppIndex !== null && (
                  <div className="absolute inset-0 bg-slate-900/90 text-white z-10 flex flex-col p-4 animate-fade-in text-xs font-sans">
                    <div className="flex items-center space-x-2 border-b border-slate-700 pb-2 mb-3">
                      <div className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-ping"></div>
                      <span className="font-mono text-[10px] text-amber-400">EJECUTANDO SECUENCIA ACCESIBILIDAD</span>
                    </div>

                    {/* Step display */}
                    <div className="flex-1 flex flex-col justify-center">
                      
                      {/* Step 1: Opening Settings */}
                      {simStep === "opening_settings" && (
                        <div className="space-y-4 animate-pulse">
                          <div className="bg-slate-850 p-3 rounded-xl border border-slate-700">
                            <span className="text-[10px] uppercase text-slate-400 block font-bold mb-1">Paso 1: Iniciando Intent</span>
                            <div className="font-mono text-blue-400 text-[11px] mb-1">
                              startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS))
                            </div>
                            <p className="text-[11px] text-white">
                              Entrando a la pantalla de Ajustes para: <strong className="text-amber-300">{apps[currentSimAppIndex].name}</strong>...
                            </p>
                          </div>
                          
                          <div className="flex items-center justify-center">
                            <RefreshCw className="w-6 h-6 animate-spin text-blue-400" />
                          </div>
                        </div>
                      )}

                      {/* Step 2: Clicking Force Stop button */}
                      {simStep === "clicking_stop" && (
                        <div className="space-y-3">
                          <span className="text-[10px] uppercase text-slate-400 block font-bold">Paso 2: Leyendo Árbol de Vistas (AccessibilityNodeInfo)</span>
                          
                          {/* Simulated Android Settings Screen */}
                          <div className="bg-slate-800 rounded-xl p-3 border border-slate-600 relative overflow-hidden">
                            <div className="text-[10px] text-slate-400">Detalles de la app</div>
                            <div className="text-sm font-bold text-white mt-1 mb-3">{apps[currentSimAppIndex].name}</div>
                            
                            <div className="flex justify-between gap-2">
                              <button className="flex-1 bg-slate-700 text-slate-300 py-1 rounded text-[10px] pointer-events-none uppercase">
                                Desinstalar
                              </button>
                              
                              <button className="flex-1 bg-[#B91C1C] text-white py-1 rounded text-[11px] font-bold uppercase cursor-pointer animate-pulse relative">
                                FORZAR DETENCIÓN
                                {/* Simulated tap click effect */}
                                <span className="absolute -inset-1 rounded-sm border-2 border-white animate-ping opacity-75"></span>
                              </button>
                            </div>

                            <p className="text-[10px] text-yellow-300 italic mt-3 text-center">
                              ✓ Encontrado nodo text: &quot;Forzar detención&quot;. Simulando clic...
                            </p>
                          </div>
                        </div>
                      )}

                      {/* Step 3: Triggering Android Dialog Confirmation */}
                      {simStep === "confirming_modal" && (
                        <div className="space-y-4">
                          <span className="text-[10px] uppercase text-slate-400 block font-bold">Paso 3: Confirmación de Diálogo de Android</span>
                          
                          {/* Simulated Alert Dialog overlay */}
                          <div className="bg-slate-800 rounded-xl p-4 border border-slate-600 shadow-xl max-w-[280px] mx-auto">
                            <p className="font-bold text-slate-100 text-xs">¿Forzar detención?</p>
                            <p className="text-[10px] text-slate-300 mt-1 leading-normal">
                              Si fuerzas la detención de una aplicación, es posible que no funcione correctamente.
                            </p>
                            <div className="mt-4 flex justify-end space-x-3 text-blue-400 font-bold text-[11px]">
                              <span className="opacity-50">CANCELAR</span>
                              <span className="bg-blue-600 text-white px-2 py-0.5 rounded cursor-pointer relative">
                                ACEPTAR
                                <span className="absolute -inset-1 rounded border-2 border-white animate-ping"></span>
                              </span>
                            </div>
                          </div>

                          <p className="text-[10px] text-green-400 italic text-center">
                            ✓ Diálogo detectado en pantalla de Accesibilidad. Clic en &apos;Aceptar&apos;...
                          </p>
                        </div>
                      )}

                      {/* Step 4: Closing / Returning */}
                      {simStep === "closing" && (
                        <div className="text-center py-4 space-y-2">
                          <div className="inline-block p-2 bg-green-500 rounded-full text-white">
                            <Check className="w-6 h-6" />
                          </div>
                          <p className="text-xs font-bold text-green-400">¡PROCESO DETENIDO CON ÉXITO!</p>
                          <p className="text-[11px] opacity-75">
                            Liberados <strong className="text-white">{apps[currentSimAppIndex].ramMb} MB</strong> genuinos de RAM.
                          </p>
                          <p className="text-[10px] text-slate-400 font-mono">
                            performGlobalAction(GLOBAL_ACTION_BACK)
                          </p>
                        </div>
                      )}

                    </div>

                    <div className="mt-2 text-center text-[9px] text-slate-500">
                      Simulando dispositivo lento de 2GB de RAM...
                    </div>
                  </div>
                )}

                {/* Subtitle list controls */}
                <div className="flex justify-between items-center px-1 mb-2.5">
                  <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                    Whitelist (Ignorar en el barrido)
                  </h3>
                  <button 
                    disabled={isSimulating}
                    onClick={() => {
                      setApps(prev => prev.map(app => app.isSystem ? app : { ...app, isWhitelisted: true }));
                    }}
                    className={`text-[10px] font-bold text-blue-600 hover:underline ${isSimulating ? "opacity-50 select-none" : "cursor-pointer"}`}
                  >
                    Proteger Todas
                  </button>
                </div>

                {/* List items */}
                <div className="space-y-1.5">
                  {apps.map((app) => (
                    <div 
                      key={app.id} 
                      className={`flex items-center justify-between p-2.5 rounded-xl border transition ${
                        app.isSystem 
                          ? "bg-slate-50 border-slate-100 opacity-80" 
                          : app.status === "killed"
                          ? "bg-emerald-50/50 border-emerald-100 opacity-60"
                          : "bg-white border-slate-100 hover:border-slate-200"
                      }`}
                    >
                      <div className="flex items-center space-x-2.5">
                        <div className={`p-1.5 rounded-lg flex items-center justify-center text-xs ${
                          app.isSystem 
                            ? "bg-slate-100 text-slate-500" 
                            : app.status === "killed"
                            ? "bg-emerald-100 text-emerald-700" 
                            : app.category === "Red Social"
                            ? "bg-blue-50 text-blue-600"
                            : app.category === "Juego"
                            ? "bg-rose-50 text-rose-600"
                            : "bg-amber-50 text-amber-600"
                        }`}>
                          <Layers className="w-4 h-4" />
                        </div>
                        
                        <div>
                          <div className="flex items-center space-x-1.5">
                            <span className="text-xs font-bold text-slate-800">{app.name}</span>
                            {app.isSystem && (
                              <span className="text-[8px] bg-slate-200 text-slate-600 px-1 py-0.2 rounded font-semibold uppercase">
                                System
                              </span>
                            )}
                          </div>
                          
                          <p className="text-[9px] text-slate-400 font-mono">
                            {app.status === "killed" ? (
                              <span className="text-emerald-600 font-semibold uppercase">✓ Forzado Cierre</span>
                            ) : (
                              <span>~ {app.ramMb} MB RAM</span>
                            )}
                          </p>
                        </div>
                      </div>

                      {/* Whitelist Toggle Switch */}
                      <button 
                        onClick={() => handleToggleWhitelist(app.id)}
                        disabled={isSimulating || app.isSystem}
                        className={`w-9 h-5 rounded-full relative transition duration-150 flex items-center shrink-0 ${
                          app.isWhitelisted 
                            ? "bg-blue-600 cursor-pointer" 
                            : app.isSystem
                            ? "bg-slate-300 cursor-not-allowed"
                            : "bg-slate-200 cursor-pointer hover:bg-slate-300"
                        }`}
                        title={app.isSystem ? "Las apps del sistema deben ignorarse obligatoriamente" : ""}
                      >
                        <div className={`w-3.5 h-3.5 bg-white rounded-full transition-transform absolute ${
                          app.isWhitelisted ? "right-1" : "left-1"
                        }`} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Bottom control trigger */}
              <div className="p-5 bg-white border-t border-slate-100">
                
                {ramFreedSum > 0 && !isSimulating && (
                  <div className="mb-3 p-2 bg-emerald-50 text-emerald-800 rounded-lg flex items-center justify-between text-[11px] font-medium border border-emerald-100 animate-fade-in animate-pulse">
                    <span>🎉 ¡{ramFreedSum} MB Liberados de Verdad!</span>
                    <button 
                      onClick={handleResetSimulator}
                      className="text-[10px] text-emerald-950 underline hover:no-underline font-bold"
                    >
                      Restaurar Todo
                    </button>
                  </div>
                )}

                <button 
                  onClick={startForceStopSequence}
                  disabled={isSimulating}
                  className={`w-full py-3 rounded-2xl font-bold text-xs uppercase tracking-widest shadow-md transition duration-150 flex items-center justify-center space-x-2 ${
                    isSimulating 
                      ? "bg-slate-400 text-white cursor-not-allowed" 
                      : "bg-slate-900 text-white cursor-pointer hover:bg-slate-800 hover:shadow-lg active:scale-98"
                  }`}
                >
                  {isSimulating ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Ejecutando Secuencia...</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5 text-green-400 fill-green-400" />
                      <span>Iniciar Secuencia de Cierre</span>
                    </>
                  )}
                </button>
                <p className="text-center mt-2.5 text-[9px] text-slate-400 italic">
                  Secuencia visual de accesibilidad para evitar trampas LMK
                </p>
              </div>
            </div>

            {/* Quick settings for the simulation speed */}
            <div className="flex items-center space-x-2 bg-slate-100 p-1.5 rounded-xl border border-slate-200">
              <span className="text-[10px] font-bold text-slate-500 uppercase px-1.5">Velocidad del Bucle:</span>
              <button 
                onClick={() => setSimulationSpeed("fast")} 
                className={`px-2 py-0.5 rounded text-[10px] font-bold transition ${simulationSpeed === "fast" ? "bg-white text-slate-900 shadow-2xs" : "text-slate-500"}`}
              >
                Rápido
              </button>
              <button 
                onClick={() => setSimulationSpeed("normal")} 
                className={`px-2 py-0.5 rounded text-[10px] font-bold transition ${simulationSpeed === "normal" ? "bg-white text-slate-900 shadow-2xs" : "text-slate-500"}`}
              >
                Normal
              </button>
              <button 
                onClick={() => setSimulationSpeed("slow")} 
                className={`px-2 py-0.5 rounded text-[10px] font-bold transition ${simulationSpeed === "slow" ? "bg-white text-slate-900 shadow-2xs" : "text-slate-500"}`}
              >
                Lento (Detalle)
              </button>
            </div>
          </section>

          {/* COLUMN 3: RIGHT INTERACTIVE CODE LAB (lg:col-span-4) */}
          <section className="lg:col-span-4 space-y-6">

            {/* Expert Gemini QA Terminal */}
            <div className="bg-slate-900 text-white rounded-3xl p-5 border border-slate-800 shadow-xl flex flex-col min-h-[460px]">
              
              <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
                <div className="flex items-center space-x-2">
                  <div className="bg-blue-600/20 text-blue-400 p-1.5 rounded-lg flex items-center justify-center">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">Consultor Android IA</h3>
                    <p className="text-[9px] text-slate-400">Gemini 3.5 Flash en tiempo real</p>
                  </div>
                </div>
                <div className="bg-green-500/25 border border-green-500/40 text-green-400 text-[8px] font-mono font-bold px-1.5 py-0.5 rounded uppercase">
                  ONLINE
                </div>
              </div>

              {/* Message scroll container */}
              <div className="flex-1 overflow-y-auto space-y-3 pr-1 text-xs max-h-[290px] min-h-[230px] scrollbar-thin">
                {chatMessages.map((msg) => (
                  <div 
                    key={msg.id} 
                    className={`p-3 rounded-2xl leading-relaxed ${
                      msg.role === "assistant" 
                        ? "bg-slate-800 text-slate-200" 
                        : "bg-blue-600/90 text-white self-end ml-4"
                    }`}
                  >
                    <div className="flex justify-between items-center mb-1 text-[9px] opacity-70">
                      <span className="font-bold underline uppercase">
                        {msg.role === "assistant" ? "Consultor Experto" : "Tú"}
                      </span>
                      <span>
                        {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className="whitespace-pre-line text-[11px] leading-relaxed">
                      {msg.content}
                    </p>
                  </div>
                ))}
                {isSendingChat && (
                  <div className="bg-slate-800 text-slate-400 p-3 rounded-2xl text-[11px] flex items-center space-x-2">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-400" />
                    <span>Gemini analizando árbol de compilación y LMK...</span>
                  </div>
                )}
                <div ref={chatBottomRef} />
              </div>

              {/* Recommended Quick Prompts */}
              <div className="mb-2 mt-4">
                <p className="text-[9px] font-bold text-slate-500 uppercase mb-1.5">Preguntas rápidas recomendadas:</p>
                <div className="flex flex-wrap gap-1.5">
                  {PRE_SUGGESTED_PROMPTS.map((qp, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleSendChat(qp.prompt)}
                      disabled={isSendingChat}
                      className="text-[10px] bg-slate-800 hover:bg-slate-700 active:bg-slate-750 text-slate-300 px-2 py-1 rounded-lg transition duration-700 cursor-pointer text-left line-clamp-1 truncate max-w-full disabled:opacity-50"
                    >
                      {qp.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Input Chat Field */}
              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSendChat();
                }}
                className="flex items-center space-x-2 pt-2 border-t border-slate-800"
              >
                <input 
                  type="text" 
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Consúltale a la IA sobre RAM o Kotlin..."
                  className="flex-1 bg-slate-800 hover:bg-slate-850 focus:bg-slate-850 hover:border-slate-700 focus:outline-hidden focus:ring-1 focus:ring-blue-500 border border-slate-700 text-slate-200 text-xs px-3.5 py-2 rounded-xl placeholder-slate-400 placeholder:text-[10px] transition"
                  disabled={isSendingChat}
                />
                <button 
                  type="submit"
                  disabled={isSendingChat || !chatInput.trim()}
                  className="bg-blue-600 hover:bg-blue-500 active:scale-95 text-white p-2 rounded-xl transition cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            </div>

            {/* Quick help link or guide */}
            <div className="bg-slate-100 p-4 border border-slate-200 rounded-2xl flex items-start space-x-3 text-xs leading-relaxed">
              <Info className="w-5 h-5 text-blue-600 mt-0.5 shrink-0" />
              <div>
                <strong className="text-slate-900 block font-semibold mb-0.5">Permisos especiales del Android Manifest</strong>
                <p className="text-slate-500 text-[11px]">
                  Fíjate en las pestañas del código en la parte inferior para ver cómo cambia la declaración de <code className="bg-white px-1 py-0.5 rounded text-pink-600 font-mono">QUERY_ALL_PACKAGES</code> según la versión de Android elegida.
                </p>
              </div>
            </div>

          </section>
        </div>

        {/* SECTION 4: INTERACTIVE CODE LAB (lg:col-span-12, taking full width below) */}
        <section id="codelab" className="mt-12 bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden mb-12">
          
          {/* Section banner */}
          <div className="bg-slate-900 text-white p-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex items-center space-x-3.5">
              <div className="bg-blue-600 text-white p-2.5 rounded-2xl flex items-center justify-center">
                <Code className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-lg font-bold tracking-tight">Laboratorio de Código Real en Kotlin</h2>
                <p className="text-xs text-slate-400">Implementación de un Servicio de Accesibilidad para automatizar Detenciones Forzadas sin Root</p>
              </div>
            </div>

            <div className="flex items-center space-x-2 text-xs">
              <span className="text-slate-400 bg-slate-800 px-2.5 py-1 rounded-lg">
                Filtro actual: <strong className="text-blue-400 font-semibold">{androidVersion}</strong>
              </span>
              <span className="text-slate-400 bg-slate-800 px-2.5 py-1 rounded-lg">
                Complejidad: <strong className="text-blue-400 font-semibold">{experienceLevel}</strong>
              </span>
            </div>
          </div>

          {/* Interactive file selector / tabs */}
          <div className="border-b border-slate-200 bg-slate-50 px-6 flex flex-wrap gap-2 pt-2.5">
            {snippets.map((snip, idx) => (
              <button
                key={idx}
                onClick={() => setActiveSnippetTab(idx)}
                className={`px-4 py-2 text-xs font-bold rounded-t-lg transition-all duration-150 relative ${
                  activeSnippetTab === idx 
                    ? "bg-white text-blue-600 border-t-2 border-blue-600 font-semibold" 
                    : "text-slate-500 hover:text-slate-800 hover:bg-slate-100"
                }`}
              >
                <div className="flex items-center space-x-2">
                  <span className="text-[10px] opacity-60">📁</span>
                  <span>{snip.title}</span>
                </div>
              </button>
            ))}
          </div>

          {/* Code Viewer Panel with Highlights & Explanations */}
          <div className="grid grid-cols-1 lg:grid-cols-12">
            
            {/* Explanation Column (lg:col-span-4) */}
            <div className="lg:col-span-4 p-6 border-r border-slate-200 bg-slate-50/40 space-y-5">
              <div>
                <span className="text-[10px] uppercase text-slate-400 font-bold block mb-1">Ruta del archivo</span>
                <code className="bg-slate-100 text-slate-700 px-2 py-0.8 rounded text-xs select-all text-ellipsis overflow-hidden block font-mono">
                  {snippets[activeSnippetTab].filePath}
                </code>
              </div>

              <div>
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide mb-2 flex items-center space-x-1.5">
                  <Info className="w-4 h-4 text-blue-600" />
                  <span>¿Qué estamos haciendo aquí?</span>
                </h4>
                <p className="text-slate-600 text-xs leading-relaxed">
                  {snippets[activeSnippetTab].explanation}
                </p>
              </div>

              <div>
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide mb-2">Puntos clave a considerar:</h4>
                <div className="space-y-1.5 text-xs text-slate-600">
                  {snippets[activeSnippetTab].highlights.map((h, hIdx) => (
                    <div key={hIdx} className="flex items-center space-x-2 bg-white px-3 py-1.5 rounded-lg border border-slate-100 shadow-3xs">
                      <span className="w-1.5 h-1.5 bg-blue-600 rounded-full"></span>
                      <code className="font-mono text-xs text-blue-800 font-semibold">{h}</code>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 space-y-2">
                <button 
                  onClick={() => copyToClipboard(snippets[activeSnippetTab].code, activeSnippetTab)}
                  className="w-full py-2.5 px-4 bg-slate-900 hover:bg-slate-800 active:scale-98 text-white rounded-xl text-xs font-bold transition flex items-center justify-center space-x-2 cursor-pointer shadow-xs"
                >
                  {copiedSnippetIdx === activeSnippetTab ? (
                    <>
                      <Check className="w-4 h-4 text-green-300" />
                      <span>¡Copiado al Portapapeles!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Copiar Fragmento de Código</span>
                    </>
                  )}
                </button>
                <span className="text-[10px] text-slate-400 text-center block leading-normal">
                  Puedes pegar este código directamente en tu proyecto en Android Studio.
                </span>
              </div>
            </div>

            {/* Code Highlight Column (lg:col-span-8) */}
            <div className="lg:col-span-8 bg-slate-950 p-6 flex flex-col relative overflow-hidden">
              <div className="flex justify-between items-center mb-3">
                <span className="text-[10px] font-mono text-slate-500">Kotlin Source View</span>
                <span className="text-[10px] font-mono text-green-400">Syntax Highlight: Active</span>
              </div>

              <pre className="text-xs font-mono text-slate-300 overflow-x-auto max-h-[500px] leading-relaxed scrollbar-thin select-all">
                <code>{snippets[activeSnippetTab].code}</code>
              </pre>
            </div>
          </div>
        </section>

      </main>

      {/* Footer bar */}
      <footer className="bg-white border-t border-slate-200 py-10 px-6 text-slate-400 text-xs">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2 text-slate-500 font-semibold">
            <Cpu className="w-4 h-4 text-green-500" />
            <span>Honest RAM Cleaner Project Simulator • Built in Google AI Studio</span>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-slate-400 text-[10px]">Version 1.0.0</span>
            <span className="text-slate-300">|</span>
            <span className="text-slate-400 text-[10px]">No Root Require</span>
            <span className="text-slate-300">|</span>
            <span className="text-slate-400 text-[10px]">2GB RAM Optimized</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
