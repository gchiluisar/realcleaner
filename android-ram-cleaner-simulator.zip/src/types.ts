export type AndroidVersion = 
  | "Android 9"
  | "Android 10"
  | "Android 11_13"
  | "Android 14";

export type ExperienceLevel = "Principiante" | "Avanzado";

export interface MockApp {
  id: string;
  name: string;
  packageName: string;
  ramMb: number;
  initialRamMb: number;
  isSystem: boolean;
  isWhitelisted: boolean;
  status: "active" | "prevented" | "killed";
  category: "Red Social" | "Juego" | "Sistema" | "Utilidad";
  iconName: string;
}

export interface CodeSnippet {
  title: string;
  filePath: string;
  code: string;
  explanation: string;
  highlights: string[];
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}
