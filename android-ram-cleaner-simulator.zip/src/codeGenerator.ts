import { AndroidVersion, ExperienceLevel, CodeSnippet } from "./types";

export function generateCodeSnippets(
  version: AndroidVersion,
  experience: ExperienceLevel
): CodeSnippet[] {
  const isPostAndroid11 = version === "Android 11_13" || version === "Android 14";
  const experiencePrefix = experience === "Principiante" 
    ? "// MAPA PARA PRINCIPIANTES:\n// 1. Abre Android Studio\n// 2. Crea un proyecto vacío en Kotlin\n// 3. Reemplaza los archivos tal como se indica abajo.\n\n"
    : "// PERFIL DE OPTIMIZACIÓN AVANZADO:\n// Código optimizado para hilos redundantes y manejo asíncrono para evitar ANR (App Not Responding).\n\n";

  // SNIPPET 1: AndroidManifest.xml
  const manifestSnippet: CodeSnippet = {
    title: "AndroidManifest.xml",
    filePath: "app/src/main/AndroidManifest.xml",
    highlights: isPostAndroid11 
      ? ["QUERY_ALL_PACKAGES", "BIND_ACCESSIBILITY_SERVICE"]
      : ["BIND_ACCESSIBILITY_SERVICE"],
    explanation: isPostAndroid11
      ? "En Android 11+ (API 30+), el sistema restringe la visibilidad de paquetes por defecto. Para poder listar las apps de tu teléfono de 2GB es MANDATORIO declarar el permiso <queries> o QUERY_ALL_PACKAGES, de lo contrario la lista de apps saldrá vacía."
      : "Para versiones anteriores a Android 11, el listado de aplicaciones no está restrictivo. Habilitamos los permisos básicos y registramos la actividad principal con el servicio de automatización.",
    code: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.tuusuario.ramcleaner">

    <!-- Permiso crítico para leer el listado total de apps instaladas -->
    ${isPostAndroid11 ? '<uses-permission android:name="android.permission.QUERY_ALL_PACKAGES" />' : '<!-- No requiere QUERY_ALL_PACKAGES en este SDK, pero es útil incluirlo para compatibilidad futura -->'}
    
    <uses-permission android:name="android.permission.KILL_BACKGROUND_PROCESSES" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="RAM Cleaner Honest"
        android:theme="@style/Theme.AppCompat.NoActionBar">
        
        <activity 
            android:name=".MainActivity" 
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- Registramos el servicio especial de Accesibilidad que ejecutará la automatización del Forzar Cierre -->
        <service
            android:name=".AutomationService"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
            android:exported="true">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_service_config" />
        </service>
    </application>
</manifest>`
  };

  // SNIPPET 2: accessibility_service_config.xml
  const configSnippet: CodeSnippet = {
    title: "accessibility_service_config.xml",
    filePath: "app/src/main/res/xml/accessibility_service_config.xml",
    highlights: ["canRetrieveWindowContent", "flagRetrieveInteractiveWindows", "feedbackGeneric"],
    explanation: "Este archivo de metadatos le indica al sistema operativo Android que nuestra aplicación necesita permiso para leer los nombres de los botones en pantalla (para identificar 'Forzar detención') y para simular clics del usuario de forma segura.",
    code: `<?xml version="1.0" encoding="utf-8"?>
<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android"
    android:description="@string/accessibility_desc"
    android:accessibilityEventTypes="typeWindowStateChanged|typeWindowContentChanged"
    android:accessibilityFeedbackType="feedbackGeneric"
    android:notificationTimeout="100"
    android:accessibilityFlags="flagDefault|flagRetrieveInteractiveWindows|flagIncludeNotImportantViews"
    android:canRetrieveWindowContent="true"
    android:canRequestFilterKeyEvents="true"
    android:canRequestTouchExplorationMode="false" />`
  };

  // SNIPPET 3: MainActivity.kt
  const mainActivitySnippet: CodeSnippet = {
    title: "MainActivity.kt",
    filePath: "app/src/main/java/com/tuusuario/ramcleaner/MainActivity.kt",
    highlights: ["getInstalledApplications", "FLAG_SYSTEM", "SharedPreferences"],
    explanation: "Carga y visualiza las aplicaciones instaladas. Filtra las del sistema automágicamente para que el usuario de un smartphone de 2GB de RAM no colapse el sistema operativo cerrando apps de bajo nivel. Implementa además la lista blanca (Whitelist) guardada en SharedPreferences.",
    code: `${experiencePrefix}package com.tuusuario.ramcleaner

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var appAdapter: AppAdapter // Tu adaptador del listado
    private var appsList = ArrayList<AppModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sharedPreferences = getSharedPreferences("RAM_Cleaner_Prefs", Context.MODE_PRIVATE)
        val btnCleanAll = findViewById<Button>(R.id.btnCleanAll)
        
        cargarAplicaciones()

        btnCleanAll.setOnClickListener {
            val appsParaCerrar = appsList.filter { !it.isWhitelisted }
            if (appsParaCerrar.isEmpty()) {
                Toast.makeText(this, "No hay apps para cerrar.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            // Enviamos el listado de paquetes a cerrar a nuestro servicio de automatización
            AutomationService.packagesQueue.clear()
            for (app in appsParaCerrar) {
                AutomationService.packagesQueue.add(app.packageName)
            }
            
            // Iniciamos la automatización limpiando el primero en la fila
            AutomationService.startAutomation(this)
        }
    }

    private fun cargarAplicaciones() {
        val pm = packageManager
        val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        appsList.clear()

        for (appInfo in installedApps) {
            // Filtrar apps críticas del sistema
            val isSystemApp = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val isUpdatedSystemApp = (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
            
            if (!isSystemApp && !isUpdatedSystemApp) {
                val appName = appInfo.loadLabel(pm).toString()
                val packageName = appInfo.packageName
                val isWhitelisted = sharedPreferences.getBoolean(packageName, false)
                
                appsList.add(AppModel(appName, packageName, isWhitelisted))
            }
        }
    }
}`
  };

  // SNIPPET 4: AutomationService.kt
  const automationServiceSnippet: CodeSnippet = {
    title: "AutomationService.kt",
    filePath: "app/src/main/java/com/tuusuario/ramcleaner/AutomationService.kt",
    highlights: ["AccessibilityService", "AccessibilityNodeInfo", "performAction", "ACTION_CLICK"],
    explanation: "La gema de la corona. Este servicio lee el estado de la pantalla cuando Android abre la configuración de cada aplicación. Busca dinámicamente un botón cuyo texto sea 'Forzar detención' o 'Forzar parada', le hace clic mediante código de accesibilidad, acepta la advertencia del sistema automáticamente, y regresa a la app principal para disparar la siguiente.",
    code: `${experiencePrefix}package com.tuusuario.ramcleaner

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Queue
import java.util.LinkedList

class AutomationService : AccessibilityService() {

    companion object {
        val packagesQueue: Queue<String> = LinkedList()
        private var isRunning = false

        fun startAutomation(context: Context) {
            if (packagesQueue.isNotEmpty()) {
                isRunning = true
                procesarSiguienteApp(context)
            }
        }

        private fun procesarSiguienteApp(context: Context) {
            if (packagesQueue.isEmpty()) {
                isRunning = false
                return
            }
            val targetPackage = packagesQueue.poll()
            
            // Lanzamos la pantalla 'Detalles de la Aplicación' en la configuración de Android
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:\$targetPackage")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (!isRunning) return

        val rootNode = rootInActiveWindow ?: return

        // 1. Buscamos y simulamos clic en el botón "Forzar Detención" / "Forzar Parada" o equivalentes en inglés
        val botonesDeParada = buscarNodosPorTexto(rootNode, listOf(
            "Forzar detención", 
            "Forzar parada", 
            "Forzar detencion",
            "Force stop", 
            "Detener"
        ))

        for (nodo in botonesDeParada) {
            if (nodo.isEnabled && nodo.isClickable) {
                nodo.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                
                // Pequeño retardo para dar tiempo a que aparezca el diálogo de confirmación de Android
                try { Thread.sleep(180) } catch (e: Exception) {}
                
                // 2. Buscamos y aceptamos el diálogo de confirmación del sistema
                val rootConfirmar = rootInActiveWindow ?: return
                val botonesAceptar = buscarNodosPorTexto(rootConfirmar, listOf(
                    "Aceptar", 
                    "OK", 
                    "Forzar detención", 
                    "Force stop"
                ))
                
                for (nodoOk in botonesAceptar) {
                     if (nodoOk.isClickable) {
                         nodoOk.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                         
                         // Volver atrás automáticamente tras forzar cierre para el siguiente ciclo
                         performGlobalAction(GLOBAL_ACTION_BACK)
                         
                         // Procesar la siguiente aplicación de la cola con retardo
                         postProcesarSiguiente()
                         return
                     }
                }
            }
        }
    }

    private fun postProcesarSiguiente() {
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        handler.postDelayed({
            procesarSiguienteApp(applicationContext)
        }, 500) // Retardo de seguridad para dispositivos lentos de 2GB de RAM
    }

    private fun buscarNodosPorTexto(
        node: AccessibilityNodeInfo, 
        textosABuscar: List<String>
    ): List<AccessibilityNodeInfo> {
        val result = ArrayList<AccessibilityNodeInfo>()
        
        // Búsqueda exhaustiva recursiva en el árbol de vistas de accesibilidad
        if (node.text != null) {
            val nodeText = node.text.toString().lowercase()
            for (texto in textosABuscar) {
                if (nodeText == texto.lowercase()) {
                    result.add(node)
                }
            }
        }
        
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            if (child != null) {
                result.addAll(buscarNodosPorTexto(child, textosABuscar))
            }
        }
        return result
    }

    override fun onInterrupt() {
        isRunning = false
    }
}`
  };

  return [manifestSnippet, configSnippet, mainActivitySnippet, automationServiceSnippet];
}
